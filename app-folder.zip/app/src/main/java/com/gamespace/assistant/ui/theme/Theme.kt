package com.gamespace.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GameSpaceDarkColors = darkColorScheme(
    background = BackgroundDeep,
    surface = CardSurface,
    surfaceVariant = CardSurface,
    primary = AccentPrimary,
    secondary = AccentSecondary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onPrimary = Color(0xFF00161F),
    error = DangerRed,
    onError = Color.White,
)

@Composable
fun GameSpaceTheme(
    // The app intentionally ships one premium dark gaming identity by default;
    // dynamic/system theming can be layered on later without changing the API surface.
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GameSpaceDarkColors,
        typography = GameSpaceTypography,
        content = content
    )
}
