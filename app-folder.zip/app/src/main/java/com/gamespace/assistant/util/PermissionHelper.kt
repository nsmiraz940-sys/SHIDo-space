package com.gamespace.assistant.util

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Every check here corresponds to a permission requested only at the moment its feature is
 * opened (Section 22) — never at app startup.
 */
object PermissionHelper {

    fun canDrawOverlays(context: Context): Boolean =
        Settings.canDrawOverlays(context)

    fun overlayPermissionIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )

    fun canWriteSettings(context: Context): Boolean =
        Settings.System.canWrite(context)

    fun writeSettingsPermissionIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:${context.packageName}")
        )

    fun hasNotificationPolicyAccess(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    fun notificationPolicyAccessIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)

    fun hasUsageAccess(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    "android:get_usage_stats",
                    android.os.Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    "android:get_usage_stats",
                    android.os.Process.myUid(),
                    context.packageName
                )
            }
            mode == android.app.AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    fun usageAccessIntent(): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    /** Human-readable explanation shown before every permission request (Section 22). */
    fun explanationFor(feature: PermissionedFeature): String = when (feature) {
        PermissionedFeature.OVERLAY -> "The floating Gaming Sidebar needs \"Display over other apps\" so its quick tools can appear on top of your game."
        PermissionedFeature.WRITE_SETTINGS -> "Adjusting brightness, screen timeout, or rotation lock system-wide needs \"Modify system settings\"."
        PermissionedFeature.NOTIFICATION_POLICY -> "Gaming Focus needs \"Do Not Disturb access\" to silence non-urgent notifications while you play."
        PermissionedFeature.USAGE_ACCESS -> "Automatically starting a session when you launch a game needs \"Usage access\" so the app can see which app is in the foreground — it does not read any content, only which app is active."
        PermissionedFeature.MEDIA_PROJECTION -> "Screen recording needs your one-time approval of Android's screen-capture dialog. This is required by Android for every recording session and cannot be skipped."
    }
}

enum class PermissionedFeature { OVERLAY, WRITE_SETTINGS, NOTIFICATION_POLICY, USAGE_ACCESS, MEDIA_PROJECTION }
