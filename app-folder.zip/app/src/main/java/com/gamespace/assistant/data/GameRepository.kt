package com.gamespace.assistant.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.gamespace.assistant.model.Game
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A launchable app the user could add to their Gaming Library. */
data class InstalledAppInfo(
    val packageName: String,
    val displayName: String,
    val isLikelyGame: Boolean,
)

class GameRepository(private val context: Context) {

    private val prefs = GamePreferences(context)
    val library = prefs.library

    /**
     * Lists every launchable app on the device (Section 20: manual add from any installed app).
     * "isLikelyGame" is a soft heuristic (ApplicationInfo.CATEGORY_GAME, API 26+) used only to
     * pre-sort suggestions in the UI — the user still explicitly confirms what counts as a game,
     * per the brief's "do not assume every installed application is a game".
     */
    suspend fun listLaunchableApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)

        resolved
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { resolveInfo ->
                val appInfo = resolveInfo.activityInfo.applicationInfo
                val label = resolveInfo.loadLabel(pm).toString()
                val likelyGame = isLikelyGame(appInfo)
                InstalledAppInfo(
                    packageName = appInfo.packageName,
                    displayName = label,
                    isLikelyGame = likelyGame,
                )
            }
            .sortedWith(compareByDescending<InstalledAppInfo> { it.isLikelyGame }.thenBy { it.displayName.lowercase() })
    }

    private fun isLikelyGame(appInfo: ApplicationInfo): Boolean {
        return try {
            // ApplicationInfo.category / CATEGORY_GAME available since API 26
            appInfo.category == ApplicationInfo.CATEGORY_GAME
        } catch (e: Exception) {
            false
        }
    }

    suspend fun addGame(app: InstalledAppInfo) {
        prefs.addGame(Game(packageName = app.packageName, displayName = app.displayName))
    }

    suspend fun removeGame(packageName: String) = prefs.removeGame(packageName)

    suspend fun toggleFavorite(packageName: String) {
        prefs.updateGame(packageName) { it.copy(isFavorite = !it.isFavorite) }
    }

    suspend fun setProfile(packageName: String, profileId: String) {
        prefs.updateGame(packageName) { it.copy(profileId = profileId) }
    }

    suspend fun reorder(newOrder: List<String>) = prefs.reorder(newOrder)

    suspend fun recordSessionEnd(packageName: String, sessionDurationMillis: Long) {
        prefs.updateGame(packageName) {
            it.copy(
                totalPlaytimeMillis = it.totalPlaytimeMillis + sessionDurationMillis,
                lastPlayedAtMillis = System.currentTimeMillis(),
            )
        }
    }

    /** Returns a launch Intent for the given package, or null if it's no longer installed. */
    fun getLaunchIntent(packageName: String): Intent? =
        context.packageManager.getLaunchIntentForPackage(packageName)

    fun isPackageInstalled(packageName: String): Boolean = try {
        context.packageManager.getApplicationInfo(packageName, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}
