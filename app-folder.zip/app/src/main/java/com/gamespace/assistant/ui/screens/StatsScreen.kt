package com.gamespace.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.ui.GameSpaceViewModel
import com.gamespace.assistant.ui.theme.*

@Composable
fun StatsScreen(viewModel: GameSpaceViewModel) {
    val library by viewModel.library.collectAsState()
    val totalMinutes = library.sumOf { it.totalPlaytimeMillis } / 60000

    Column(
        Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(16.dp)
    ) {
        Text("Stats", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "Session-by-session breakdowns (today/week/month) land in Phase 2, once automatic " +
                "launch/exit detection is wired to Usage Access. Totals below are already real.",
            color = TextMuted, style = MaterialTheme.typography.labelSmall
        )
        Spacer(Modifier.height(16.dp))

        Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("$totalMinutes min", style = MaterialTheme.typography.headlineLarge, color = AccentPrimary)
                Text("Total tracked playtime, all time", color = TextMuted)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Per game", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(library.sortedByDescending { it.totalPlaytimeMillis }) { game ->
                Surface(shape = RoundedCornerShape(12.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(game.displayName, color = TextPrimary)
                        Text("${game.totalPlaytimeMillis / 60000} min", color = TextMuted)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
