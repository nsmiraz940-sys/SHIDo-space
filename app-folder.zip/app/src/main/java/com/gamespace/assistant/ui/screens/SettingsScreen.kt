package com.gamespace.assistant.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.util.PermissionHelper
import com.gamespace.assistant.util.PermissionedFeature
import com.gamespace.assistant.ui.theme.*

@Composable
fun SettingsScreen() {
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(Modifier.height(16.dp))

        SettingsSection("Gaming") {
            PermissionRow(
                title = "Floating Sidebar",
                feature = PermissionedFeature.OVERLAY,
                isGranted = PermissionHelper.canDrawOverlays(context),
                onRequest = { context.startActivity(PermissionHelper.overlayPermissionIntent(context)) }
            )
            PermissionRow(
                title = "System brightness / rotation / timeout control",
                feature = PermissionedFeature.WRITE_SETTINGS,
                isGranted = PermissionHelper.canWriteSettings(context),
                onRequest = { context.startActivity(PermissionHelper.writeSettingsPermissionIntent(context)) }
            )
            PermissionRow(
                title = "Gaming Focus (Do Not Disturb)",
                feature = PermissionedFeature.NOTIFICATION_POLICY,
                isGranted = PermissionHelper.hasNotificationPolicyAccess(context),
                onRequest = { context.startActivity(PermissionHelper.notificationPolicyAccessIntent()) }
            )
            PermissionRow(
                title = "Auto-detect game launch/exit",
                feature = PermissionedFeature.USAGE_ACCESS,
                isGranted = PermissionHelper.hasUsageAccess(context),
                onRequest = { context.startActivity(PermissionHelper.usageAccessIntent()) }
            )
        }

        Spacer(Modifier.height(20.dp))
        SettingsSection("Privacy") {
            Text(
                "GameSpace stores your library and session stats only on this device. " +
                    "No account, no ads, no analytics SDK, nothing uploaded.",
                color = TextMuted, style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { /* wired to a confirmation dialog + DataStore clear in Phase 2 */ }) {
                Text("Clear all gaming data", color = DangerRed)
            }
        }

        Spacer(Modifier.height(20.dp))
        SettingsSection("About") {
            Text("GameSpace 0.1.0 (Phase 1)", color = TextMuted)
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = AccentPrimary)
    Spacer(Modifier.height(8.dp))
    Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
private fun PermissionRow(
    title: String,
    feature: PermissionedFeature,
    isGranted: Boolean,
    onRequest: () -> Unit,
) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(title, color = TextPrimary)
            if (isGranted) {
                Text("Granted", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
            } else {
                TextButton(onClick = onRequest) { Text("Grant", color = AccentPrimary) }
            }
        }
        if (!isGranted) {
            Text(
                PermissionHelper.explanationFor(feature),
                color = TextMuted, style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
