package com.gamespace.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.data.InstalledAppInfo
import com.gamespace.assistant.model.Game
import com.gamespace.assistant.model.GamingProfile
import com.gamespace.assistant.ui.GameSpaceViewModel
import com.gamespace.assistant.ui.theme.*

@Composable
fun GamesScreen(viewModel: GameSpaceViewModel) {
    val library by viewModel.library.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    var query by remember { mutableStateOf("") }
    var showAddSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refreshInstalledApps() }

    Column(
        Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Gaming Library", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Button(onClick = { showAddSheet = true }, colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)) {
                Text("Add game", color = BackgroundDeep)
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search your library") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
                focusedBorderColor = AccentPrimary, unfocusedBorderColor = TextMuted
            )
        )
        Spacer(Modifier.height(12.dp))

        val filtered = library.filter { it.displayName.contains(query, ignoreCase = true) }
        LazyColumn {
            items(filtered, key = { it.packageName }) { game ->
                LibraryRow(
                    game = game,
                    onToggleFavorite = { viewModel.toggleFavorite(game.packageName) },
                    onRemove = { viewModel.removeGame(game.packageName) },
                    onProfileSelected = { viewModel.setProfile(game.packageName, it) },
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showAddSheet) {
        AddGameSheet(
            apps = installedApps,
            alreadyAdded = library.map { it.packageName }.toSet(),
            onAdd = { viewModel.addGame(it) },
            onDismiss = { showAddSheet = false }
        )
    }
}

@Composable
private fun LibraryRow(
    game: Game,
    onToggleFavorite: () -> Unit,
    onRemove: () -> Unit,
    onProfileSelected: (GamingProfile) -> Unit,
) {
    var profileMenuOpen by remember { mutableStateOf(false) }
    Surface(shape = RoundedCornerShape(14.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(game.displayName, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                Row {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (game.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (game.isFavorite) DangerRed else TextMuted
                        )
                    }
                    TextButton(onClick = onRemove) { Text("Remove", color = DangerRed) }
                }
            }
            Spacer(Modifier.height(6.dp))
            Box {
                AssistChip(
                    onClick = { profileMenuOpen = true },
                    label = { Text(GamingProfile.BUILT_IN.firstOrNull { it.id == game.profileId }?.name ?: "Balanced") }
                )
                DropdownMenu(expanded = profileMenuOpen, onDismissRequest = { profileMenuOpen = false }) {
                    GamingProfile.BUILT_IN.forEach { profile ->
                        DropdownMenuItem(
                            text = { Text(profile.name) },
                            onClick = {
                                onProfileSelected(profile)
                                profileMenuOpen = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddGameSheet(
    apps: List<InstalledAppInfo>,
    alreadyAdded: Set<String>,
    onAdd: (InstalledAppInfo) -> Unit,
    onDismiss: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = CardSurface) {
        Column(Modifier.padding(16.dp)) {
            Text("Add from installed apps", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            Text(
                "Apps Android flags as games are shown first — you decide what actually counts.",
                color = TextMuted, style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search installed apps") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(apps.filter { it.displayName.contains(query, true) && it.packageName !in alreadyAdded }) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(app.displayName, color = TextPrimary)
                            if (app.isLikelyGame) Text("Likely a game", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(onClick = { onAdd(app) }) { Text("Add", color = AccentPrimary) }
                    }
                }
            }
        }
    }
}
