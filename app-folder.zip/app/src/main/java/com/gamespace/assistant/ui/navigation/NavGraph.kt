package com.gamespace.assistant.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.gamespace.assistant.ui.GameSpaceViewModel
import com.gamespace.assistant.ui.screens.*
import com.gamespace.assistant.ui.theme.AccentPrimary
import com.gamespace.assistant.ui.theme.CardSurface
import com.gamespace.assistant.ui.theme.TextMuted

sealed class Destination(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Destination("home", "Home", Icons.Default.Home)
    data object Games : Destination("games", "Games", Icons.Default.SportsEsports)
    data object Stats : Destination("stats", "Stats", Icons.Default.BarChart)
    data object Tools : Destination("tools", "Tools", Icons.Default.Build)
    data object Settings : Destination("settings", "Settings", Icons.Default.Settings)
}

private val destinations = listOf(
    Destination.Home, Destination.Games, Destination.Stats, Destination.Tools, Destination.Settings
)

@Composable
fun GameSpaceNavHost(
    viewModel: GameSpaceViewModel,
    onLaunchGame: (com.gamespace.assistant.model.Game) -> Unit,
    onRequestScreenRecording: () -> Unit,
) {
    val navController = rememberNavController()

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color(0xFF080A0F),
        bottomBar = {
            NavigationBar(containerColor = CardSurface) {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                destinations.forEach { dest ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentPrimary,
                            selectedTextColor = AccentPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = CardSurface,
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Destination.Home.route) {
                HomeScreen(viewModel, onLaunchGame = onLaunchGame, onOpenGames = {
                    navController.navigate(Destination.Games.route)
                })
            }
            composable(Destination.Games.route) { GamesScreen(viewModel) }
            composable(Destination.Stats.route) { StatsScreen(viewModel) }
            composable(Destination.Tools.route) { ToolsScreen(onRequestScreenRecording) }
            composable(Destination.Settings.route) { SettingsScreen() }
        }
    }
}
