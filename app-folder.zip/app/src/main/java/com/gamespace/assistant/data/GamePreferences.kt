package com.gamespace.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.gamespace.assistant.model.Game
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "gamespace_prefs")

/**
 * Persists the user's Gaming Library and per-game settings.
 * Uses DataStore (not Room) since the data is a small, flat set of preference-shaped records —
 * matches the brief's "Room only if persistent structured data is necessary".
 */
class GamePreferences(private val context: Context) {

    private object Keys {
        val LIBRARY_JSON = stringPreferencesKey("library_json")
        val FAVORITES = stringSetPreferencesKey("favorite_packages")
        val LAST_ACTIVE_PROFILE = stringPreferencesKey("last_active_profile")
    }

    val library: Flow<List<Game>> = context.dataStore.data.map { prefs ->
        val json = prefs[Keys.LIBRARY_JSON] ?: return@map emptyList()
        parseLibrary(json)
    }

    suspend fun saveLibrary(games: List<Game>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LIBRARY_JSON] = serializeLibrary(games)
        }
    }

    suspend fun addGame(game: Game) {
        context.dataStore.edit { prefs ->
            val current = parseLibrary(prefs[Keys.LIBRARY_JSON] ?: "[]").toMutableList()
            if (current.none { it.packageName == game.packageName }) {
                current.add(game.copy(sortOrder = current.size))
                prefs[Keys.LIBRARY_JSON] = serializeLibrary(current)
            }
        }
    }

    suspend fun removeGame(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = parseLibrary(prefs[Keys.LIBRARY_JSON] ?: "[]")
                .filterNot { it.packageName == packageName }
            prefs[Keys.LIBRARY_JSON] = serializeLibrary(current)
        }
    }

    suspend fun updateGame(packageName: String, transform: (Game) -> Game) {
        context.dataStore.edit { prefs ->
            val current = parseLibrary(prefs[Keys.LIBRARY_JSON] ?: "[]").map {
                if (it.packageName == packageName) transform(it) else it
            }
            prefs[Keys.LIBRARY_JSON] = serializeLibrary(current)
        }
    }

    suspend fun reorder(newOrder: List<String>) {
        context.dataStore.edit { prefs ->
            val current = parseLibrary(prefs[Keys.LIBRARY_JSON] ?: "[]")
                .associateBy { it.packageName }
            val reordered = newOrder.mapIndexedNotNull { index, pkg ->
                current[pkg]?.copy(sortOrder = index)
            }
            prefs[Keys.LIBRARY_JSON] = serializeLibrary(reordered)
        }
    }

    private fun serializeLibrary(games: List<Game>): String {
        val arr = JSONArray()
        games.forEach { g ->
            arr.put(JSONObject().apply {
                put("packageName", g.packageName)
                put("displayName", g.displayName)
                put("isFavorite", g.isFavorite)
                put("sortOrder", g.sortOrder)
                put("profileId", g.profileId)
                put("totalPlaytimeMillis", g.totalPlaytimeMillis)
                put("lastPlayedAtMillis", g.lastPlayedAtMillis ?: JSONObject.NULL)
                put("customIconUri", g.customIconUri ?: JSONObject.NULL)
            })
        }
        return arr.toString()
    }

    private fun parseLibrary(json: String): List<Game> {
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Game(
                    packageName = o.getString("packageName"),
                    displayName = o.getString("displayName"),
                    isFavorite = o.optBoolean("isFavorite", false),
                    sortOrder = o.optInt("sortOrder", 0),
                    profileId = o.optString("profileId", "balanced"),
                    totalPlaytimeMillis = o.optLong("totalPlaytimeMillis", 0L),
                    lastPlayedAtMillis = if (o.isNull("lastPlayedAtMillis")) null else o.optLong("lastPlayedAtMillis"),
                    customIconUri = if (o.isNull("customIconUri")) null else o.optString("customIconUri"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
