package com.gamespace.assistant.model

/**
 * A single entry in the user's Gaming Library.
 * Only apps the user explicitly added are treated as games — the app never assumes
 * every installed package is a game.
 */
data class Game(
    val packageName: String,
    val displayName: String,
    val isFavorite: Boolean = false,
    val sortOrder: Int = 0,
    val profileId: String = GamingProfile.BALANCED.id,
    val totalPlaytimeMillis: Long = 0L,
    val lastPlayedAtMillis: Long? = null,
    val customIconUri: String? = null,
)

/**
 * An app-controllable settings bundle. Every field here maps to something this app can
 * legitimately apply (its own window/session behavior, or a user-granted system setting) —
 * nothing here implies kernel/driver/root-level control.
 */
data class GamingProfile(
    val id: String,
    val name: String,
    val isBuiltIn: Boolean = true,
    val suppressNotifications: Boolean = false,
    val keepScreenOnDuringSession: Boolean = false,
    val preferHighestRefreshRate: Boolean = false,
    val reduceOverlayPollingForBattery: Boolean = false,
    val enableTouchProtectionOverlay: Boolean = false,
    val brightnessOverridePercent: Int? = null, // null = leave brightness alone
) {
    companion object {
        val BALANCED = GamingProfile(
            id = "balanced",
            name = "Balanced",
            suppressNotifications = false,
            keepScreenOnDuringSession = true,
            preferHighestRefreshRate = false,
            reduceOverlayPollingForBattery = false,
        )
        val PERFORMANCE = GamingProfile(
            id = "performance",
            name = "Performance",
            suppressNotifications = false,
            keepScreenOnDuringSession = true,
            preferHighestRefreshRate = true,
            reduceOverlayPollingForBattery = false,
        )
        val COMPETITIVE = GamingProfile(
            id = "competitive",
            name = "Competitive",
            suppressNotifications = true,
            keepScreenOnDuringSession = true,
            preferHighestRefreshRate = true,
            reduceOverlayPollingForBattery = false,
            enableTouchProtectionOverlay = true,
        )
        val BATTERY_SAVER = GamingProfile(
            id = "battery",
            name = "Battery",
            suppressNotifications = false,
            keepScreenOnDuringSession = false,
            preferHighestRefreshRate = false,
            reduceOverlayPollingForBattery = true,
        )

        val BUILT_IN = listOf(BALANCED, PERFORMANCE, COMPETITIVE, BATTERY_SAVER)
    }
}

/** A single tracked play session for statistics (Section 17). */
data class GameSession(
    val packageName: String,
    val startedAtMillis: Long,
    val endedAtMillis: Long? = null,
    val batteryPercentAtStart: Int? = null,
    val batteryPercentAtEnd: Int? = null,
    val profileIdUsed: String,
) {
    val durationMillis: Long?
        get() = endedAtMillis?.let { it - startedAtMillis }
}

/** A live snapshot of everything the Performance Monitor can honestly measure right now. */
data class SystemSnapshot(
    val batteryPercent: Int?,
    val isCharging: Boolean,
    val batteryTemperatureCelsius: Float?,
    val usedRamBytes: Long?,
    val totalRamBytes: Long?,
    val isLowMemory: Boolean,
    val thermalStatus: ThermalStatus,
    val networkType: NetworkType,
    val wifiLinkSpeedMbps: Int?,
    val wifiSignalDbm: Int?, // null unless the optional location permission was granted
    val refreshRateHz: Float?,
    val cpuUsageAvailable: Boolean = false, // always false on modern Android for a normal app — see capability matrix
)

enum class ThermalStatus { NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNKNOWN, UNAVAILABLE }
enum class NetworkType { WIFI, CELLULAR, ETHERNET, NONE, UNKNOWN }
