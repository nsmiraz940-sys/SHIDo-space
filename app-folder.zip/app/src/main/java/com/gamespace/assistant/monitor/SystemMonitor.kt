package com.gamespace.assistant.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager
import com.gamespace.assistant.model.NetworkType
import com.gamespace.assistant.model.SystemSnapshot
import com.gamespace.assistant.model.ThermalStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Produces [SystemSnapshot]s using only public, non-privileged Android APIs.
 * No field here is simulated or guessed — anything the platform doesn't expose to a normal
 * app is surfaced as `null`/UNAVAILABLE rather than a made-up number (see capability matrix).
 */
class SystemMonitor(private val context: Context) {

    /**
     * Emits a snapshot every [intervalMillis]. The interval is intentionally caller-controlled:
     * profiles with `reduceOverlayPollingForBattery = true` should pass a longer interval to
     * avoid unnecessary polling (Section 5 / 31: no excessive polling, no battery drain).
     */
    fun snapshots(intervalMillis: Long = 2000L): Flow<SystemSnapshot> = flow {
        while (true) {
            emit(captureSnapshot())
            delay(intervalMillis)
        }
    }

    fun captureSnapshot(): SystemSnapshot {
        val battery = readBattery()
        val ram = readRam()
        val thermal = readThermalStatus()
        val network = readNetworkType()
        val wifi = readWifiInfo()
        val refreshRate = readRefreshRate()

        return SystemSnapshot(
            batteryPercent = battery.percent,
            isCharging = battery.isCharging,
            batteryTemperatureCelsius = battery.temperatureCelsius,
            usedRamBytes = ram.usedBytes,
            totalRamBytes = ram.totalBytes,
            isLowMemory = ram.isLow,
            thermalStatus = thermal,
            networkType = network,
            wifiLinkSpeedMbps = wifi.linkSpeedMbps,
            wifiSignalDbm = wifi.signalDbm,
            refreshRateHz = refreshRate,
            cpuUsageAvailable = false, // Deliberately false everywhere — see FEATURE_CAPABILITY_MATRIX.md
        )
    }

    // ---- Battery ----

    private data class BatteryReading(val percent: Int?, val isCharging: Boolean, val temperatureCelsius: Float?)

    private fun readBattery(): BatteryReading {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryReading(null, false, null)

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else null

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        // EXTRA_TEMPERATURE is in tenths of a degree Celsius; some devices/ROMs omit it.
        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val tempCelsius = if (tempTenths != Int.MIN_VALUE) tempTenths / 10f else null

        return BatteryReading(percent, isCharging, tempCelsius)
    }

    // ---- RAM ----

    private data class RamReading(val usedBytes: Long?, val totalBytes: Long?, val isLow: Boolean)

    private fun readRam(): RamReading {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return RamReading(null, null, false)
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val used = info.totalMem - info.availMem
        return RamReading(usedBytes = used, totalBytes = info.totalMem, isLow = info.lowMemory)
    }

    // ---- Thermal ----

    private fun readThermalStatus(): ThermalStatus {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ThermalStatus.UNAVAILABLE
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return ThermalStatus.UNAVAILABLE
        return try {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
                PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
                else -> ThermalStatus.UNKNOWN
            }
        } catch (e: Exception) {
            ThermalStatus.UNAVAILABLE
        }
    }

    // ---- Network ----

    private fun readNetworkType(): NetworkType {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return NetworkType.UNKNOWN
        val network = cm.activeNetwork ?: return NetworkType.NONE
        val caps = cm.getNetworkCapabilities(network) ?: return NetworkType.NONE
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkType.CELLULAR
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            else -> NetworkType.UNKNOWN
        }
    }

    private data class WifiReading(val linkSpeedMbps: Int?, val signalDbm: Int?)

    private fun readWifiInfo(): WifiReading {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            ?: return WifiReading(null, null)
        return try {
            val info = wm.connectionInfo
            val linkSpeed = info?.linkSpeed?.takeIf { it >= 0 }
            // RSSI is redacted to a fixed value on API 31+ unless ACCESS_FINE_LOCATION is granted —
            // that's a platform privacy restriction, not a bug in this app.
            val signal = info?.rssi?.takeIf { it != Int.MIN_VALUE && it != 0 }
            WifiReading(linkSpeed, signal)
        } catch (e: Exception) {
            WifiReading(null, null)
        }
    }

    // ---- Display ----

    private fun readRefreshRate(): Float? {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            wm?.defaultDisplay?.refreshRate
        } catch (e: Exception) {
            null
        }
    }
}
