package com.gamespace.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.model.Game
import com.gamespace.assistant.model.NetworkType
import com.gamespace.assistant.model.SystemSnapshot
import com.gamespace.assistant.model.ThermalStatus
import com.gamespace.assistant.ui.GameSpaceViewModel
import com.gamespace.assistant.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    viewModel: GameSpaceViewModel,
    onLaunchGame: (Game) -> Unit,
    onOpenGames: () -> Unit,
) {
    val library by viewModel.library.collectAsState()
    val snapshot by viewModel.systemSnapshot.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Text("Gaming Mode", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text("Ready to play", color = AccentPrimary, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
        }
        item {
            PerformanceCard(snapshot)
            Spacer(Modifier.height(12.dp))
        }
        item {
            NetworkCard(snapshot)
            Spacer(Modifier.height(20.dp))
        }
        item {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Game Library", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                TextButton(onClick = onOpenGames) { Text("Manage", color = AccentPrimary) }
            }
            Spacer(Modifier.height(8.dp))
        }
        if (library.isEmpty()) {
            item {
                EmptyLibraryHint(onOpenGames)
            }
        } else {
            items(library.sortedByDescending { it.isFavorite }) { game ->
                GameCard(game = game, onLaunch = { onLaunchGame(game) })
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun PerformanceCard(snapshot: SystemSnapshot?) {
    Surface(shape = RoundedCornerShape(18.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            MetricColumn("CPU", "N/A", hint = "Not exposed by Android to apps")
            MetricColumn("RAM", ramLabel(snapshot))
            MetricColumn("THERMAL", thermalLabel(snapshot?.thermalStatus))
        }
    }
}

@Composable
private fun NetworkCard(snapshot: SystemSnapshot?) {
    Surface(shape = RoundedCornerShape(18.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(
                when (snapshot?.networkType) {
                    NetworkType.WIFI -> "Wi-Fi"
                    NetworkType.CELLULAR -> "Mobile data"
                    NetworkType.ETHERNET -> "Ethernet"
                    NetworkType.NONE -> "Offline"
                    else -> "Checking…"
                },
                color = TextPrimary, style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(4.dp))
            val speed = snapshot?.wifiLinkSpeedMbps
            Text(
                if (speed != null) "Link speed ${speed} Mbps" else "Latency test not yet run",
                color = TextMuted, style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun MetricColumn(label: String, value: String, hint: String? = null) {
    Column {
        Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        if (hint != null) Text(hint, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

private fun ramLabel(snapshot: SystemSnapshot?): String {
    val used = snapshot?.usedRamBytes ?: return "…"
    val total = snapshot.totalRamBytes ?: return "…"
    val usedGb = used / 1_073_741_824.0
    val totalGb = total / 1_073_741_824.0
    return "${"%.1f".format(usedGb)}/${"%.1f".format(totalGb)}GB"
}

private fun thermalLabel(status: ThermalStatus?): String = when (status) {
    ThermalStatus.NONE -> "Normal"
    ThermalStatus.LIGHT -> "Light"
    ThermalStatus.MODERATE -> "Moderate"
    ThermalStatus.SEVERE -> "Severe"
    ThermalStatus.CRITICAL, ThermalStatus.EMERGENCY, ThermalStatus.SHUTDOWN -> "Critical"
    ThermalStatus.UNAVAILABLE, null -> "N/A"
    ThermalStatus.UNKNOWN -> "Unknown"
}

@Composable
private fun GameCard(game: Game, onLaunch: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(game.displayName, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                val minutes = (game.totalPlaytimeMillis / 60000).toInt()
                Text("Playtime: ${minutes}m", color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            Button(onClick = onLaunch, colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)) {
                Text("Launch", color = BackgroundDeep)
            }
        }
    }
}

@Composable
private fun EmptyLibraryHint(onOpenGames: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("No games added yet", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Pick which installed apps are games — GameSpace never assumes for you.",
                color = TextMuted, style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onOpenGames, colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)) {
                Text("Add games", color = BackgroundDeep)
            }
        }
    }
}
