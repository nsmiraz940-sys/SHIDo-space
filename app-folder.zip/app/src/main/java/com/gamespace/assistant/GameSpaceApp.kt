package com.gamespace.assistant

import android.app.Application

class GameSpaceApp : Application()
