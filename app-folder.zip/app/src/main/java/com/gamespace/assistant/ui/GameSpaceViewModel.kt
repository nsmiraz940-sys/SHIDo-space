package com.gamespace.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gamespace.assistant.data.GameRepository
import com.gamespace.assistant.data.InstalledAppInfo
import com.gamespace.assistant.model.Game
import com.gamespace.assistant.model.GamingProfile
import com.gamespace.assistant.model.SystemSnapshot
import com.gamespace.assistant.monitor.SystemMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GameSpaceViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = GameRepository(app)
    private val monitor = SystemMonitor(app)

    val library: StateFlow<List<Game>> = repository.library
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val systemSnapshot: StateFlow<SystemSnapshot?> = monitor.snapshots(intervalMillis = 3000)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = repository.listLaunchableApps()
        }
    }

    fun addGame(app: InstalledAppInfo) = viewModelScope.launch { repository.addGame(app) }
    fun removeGame(packageName: String) = viewModelScope.launch { repository.removeGame(packageName) }
    fun toggleFavorite(packageName: String) = viewModelScope.launch { repository.toggleFavorite(packageName) }
    fun setProfile(packageName: String, profile: GamingProfile) =
        viewModelScope.launch { repository.setProfile(packageName, profile.id) }
    fun reorder(order: List<String>) = viewModelScope.launch { repository.reorder(order) }

    fun launchIntentFor(packageName: String) = repository.getLaunchIntent(packageName)
}
