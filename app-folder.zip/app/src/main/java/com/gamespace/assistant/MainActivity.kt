package com.gamespace.assistant

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.gamespace.assistant.recording.ScreenRecordService
import com.gamespace.assistant.ui.GameSpaceViewModel
import com.gamespace.assistant.ui.navigation.GameSpaceNavHost
import com.gamespace.assistant.ui.theme.GameSpaceTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GameSpaceViewModel by viewModels()

    // Handles the mandatory system consent dialog for MediaProjection (Section 7).
    // This app cannot start recording without the user approving this dialog every session.
    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenRecordService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenRecordService.EXTRA_WIDTH, resources.displayMetrics.widthPixels)
                putExtra(ScreenRecordService.EXTRA_HEIGHT, resources.displayMetrics.heightPixels)
                putExtra(ScreenRecordService.EXTRA_DPI, resources.displayMetrics.densityDpi)
            }
            startForegroundService(serviceIntent)
        } else {
            Toast.makeText(this, "Screen recording needs the system consent dialog to be approved.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GameSpaceTheme {
                GameSpaceNavHost(
                    viewModel = viewModel,
                    onLaunchGame = { game ->
                        val intent = viewModel.launchIntentFor(game.packageName)
                        if (intent != null) {
                            startActivity(intent)
                        } else {
                            Toast.makeText(this, "${game.displayName} is no longer installed", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onRequestScreenRecording = { requestScreenRecording() }
                )
            }
        }
    }

    private fun requestScreenRecording() {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
