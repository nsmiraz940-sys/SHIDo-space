package com.gamespace.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDeep = Color(0xFF080A0F)
val CardSurface = Color(0xFF111722)
val AccentPrimary = Color(0xFF35C8FF)
val AccentSecondary = Color(0xFF7DE7FF)
val TextPrimary = Color(0xFFF5F7FA)
val TextMuted = Color(0xFF8B96A7)
val DangerRed = Color(0xFFFF6577)
val SuccessGreen = Color(0xFF65E6B0)
