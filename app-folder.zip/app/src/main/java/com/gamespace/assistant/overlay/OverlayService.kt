package com.gamespace.assistant.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.gamespace.assistant.MainActivity
import com.gamespace.assistant.R
import kotlin.math.roundToInt

/**
 * Hosts the floating Gaming Sidebar (Section 3) using TYPE_APPLICATION_OVERLAY.
 *
 * Unlike a free-floating draggable bubble, this sidebar is pinned to the right edge of the
 * screen at all times: only its horizontal position changes (collapsed handle -> expanded
 * panel), animated by [GamingSidebarOverlay] and applied here via WindowManager.updateViewLayout
 * so the panel visibly slides out from the edge rather than appearing/disappearing.
 *
 * Runs as a foreground service with a visible notification the whole time it's active —
 * Android does not allow a silent, permanently-invisible overlay service, and this app
 * doesn't attempt to work around that.
 */
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        const val CHANNEL_ID = "gamespace_overlay"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.gamespace.assistant.action.STOP_OVERLAY"
        private const val COLLAPSED_WIDTH_DP = 22
        private const val EXPANDED_WIDTH_DP = 230
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private var windowManager: WindowManager? = null
    private var sidebarView: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null
    val isExpanded = mutableStateOf(false)

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            // Never crash on a revoked/denied permission — just stop cleanly.
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        if (sidebarView == null) {
            showSidebar()
        }
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        return START_STICKY
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).roundToInt()

    private fun showSidebar() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val collapsedWidthPx = dpToPx(COLLAPSED_WIDTH_DP)
        val expandedWidthPx = dpToPx(EXPANDED_WIDTH_DP)

        // Pinned to the right edge: gravity TOP|END with x = 0 means "flush against the edge".
        // We grow the window's own width for the slide, rather than moving the whole window
        // left, so the panel's right edge always stays glued to the screen edge.
        val layoutParams = WindowManager.LayoutParams(
            collapsedWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = resources.displayMetrics.heightPixels / 3 // a reasonable default vertical position; user can drag it
        }
        params = layoutParams

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                GamingSidebarOverlay(
                    expanded = isExpanded.value,
                    onToggleExpanded = { isExpanded.value = !isExpanded.value },
                    onOpenFractionChanged = { fraction ->
                        val currentParams = params ?: return@GamingSidebarOverlay
                        val newWidth = (collapsedWidthPx + (expandedWidthPx - collapsedWidthPx) * fraction).roundToInt()
                        if (currentParams.width != newWidth) {
                            currentParams.width = newWidth
                            try { wm.updateViewLayout(this, currentParams) } catch (e: Exception) { /* view may already be detached */ }
                        }
                    },
                    onVerticalDragBy = { dy ->
                        val currentParams = params ?: return@GamingSidebarOverlay
                        currentParams.y = (currentParams.y + dy.roundToInt()).coerceIn(0, resources.displayMetrics.heightPixels)
                        try { wm.updateViewLayout(this, currentParams) } catch (e: Exception) { }
                    },
                    onClose = { stopSelf() }
                )
            }
        }

        sidebarView = composeView
        wm.addView(composeView, layoutParams)
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Gaming Sidebar active")
        .setContentText("Tap to open ESPORTS MODE")
        .setSmallIcon(R.drawable.ic_overlay_notification)
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
        )
        .addAction(0, "Close sidebar", PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        ))
        .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Gaming Sidebar", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        sidebarView?.let { view ->
            try { windowManager?.removeView(view) } catch (e: Exception) { /* view already gone */ }
        }
        sidebarView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
