package com.gamespace.assistant.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.ui.theme.AccentPrimary
import com.gamespace.assistant.ui.theme.BackgroundDeep
import com.gamespace.assistant.ui.theme.CardSurface
import com.gamespace.assistant.ui.theme.TextPrimary

/**
 * Collapsed = a small draggable bubble (non-intrusive, doesn't cover game controls).
 * Expanded = the quick-actions panel (Section 3): performance readout + quick toggles.
 * Deliberately lightweight: no continuous polling while collapsed.
 */
@Composable
fun GamingSidebarOverlay(
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onDragBy: (dx: Float, dy: Float) -> Unit,
    onClose: () -> Unit,
) {
    if (!expanded) {
        Surface(
            shape = CircleShape,
            color = AccentPrimary.copy(alpha = 0.85f),
            modifier = Modifier
                .size(48.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragBy(dragAmount.x, dragAmount.y)
                    }
                }
        ) {
            IconButton(onClick = onToggleExpanded) {
                Icon(Icons.Default.SportsEsports, contentDescription = "Open gaming sidebar", tint = BackgroundDeep)
            }
        }
    } else {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CardSurface.copy(alpha = 0.96f),
            modifier = Modifier.width(220.dp)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Gaming Sidebar", color = TextPrimary)
                    IconButton(onClick = onToggleExpanded, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Collapse", tint = TextPrimary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                QuickActionRow(Icons.Default.PhotoCamera, "Screenshot")
                QuickActionRow(Icons.Default.Videocam, "Record")
                QuickActionRow(Icons.Default.BrightnessMedium, "Brightness")
                QuickActionRow(Icons.Default.DoNotDisturbOn, "Focus mode")
                QuickActionRow(Icons.Default.TouchApp, "Touch protect")
                Spacer(Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = "Close sidebar", tint = Color(0xFFFF6577))
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = AccentPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = TextPrimary)
    }
}
