package com.gamespace.assistant.overlay

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.ui.theme.AccentPrimary
import com.gamespace.assistant.ui.theme.CardSurface
import com.gamespace.assistant.ui.theme.TextPrimary

/**
 * An edge-pinned sidebar: a small handle stays flush against the screen edge at all times,
 * and slides the full panel out on tap or swipe — it never floats freely away from the edge
 * like a draggable bubble would.
 *
 * The host (OverlayService) actually moves the window horizontally; this composable just
 * reports how "open" it wants to be (0f = collapsed handle, 1f = fully open) via
 * [onOpenFractionChanged] on every animation frame, and the service repositions the
 * WindowManager params to match — that's what produces the slide.
 */
@Composable
fun GamingSidebarOverlay(
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onOpenFractionChanged: (Float) -> Unit,
    onVerticalDragBy: (dy: Float) -> Unit,
    onClose: () -> Unit,
) {
    val openFraction by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "sidebarOpenFraction"
    )
    LaunchedEffect(openFraction) { onOpenFractionChanged(openFraction) }

    if (openFraction < 0.5f) {
        Surface(
            shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
            color = AccentPrimary.copy(alpha = 0.9f),
            modifier = Modifier
                .width(22.dp)
                .height(64.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dragAmount ->
                        change.consume()
                        onVerticalDragBy(dragAmount)
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        change.consume()
                        if (dragAmount < -12f) onToggleExpanded()
                    }
                }
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                IconButton(onClick = onToggleExpanded, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Open gaming sidebar", tint = Color(0xFF00161F))
                }
            }
        }
    } else {
        Surface(
            shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
            color = CardSurface.copy(alpha = 0.97f),
            modifier = Modifier
                .width(230.dp)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        change.consume()
                        if (dragAmount > 12f) onToggleExpanded()
                    }
                }
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ESPORTS MODE", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onToggleExpanded, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Collapse", tint = TextPrimary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                QuickActionRow(Icons.Default.PhotoCamera, "Screenshot")
                QuickActionRow(Icons.Default.Videocam, "Record")
                QuickActionRow(Icons.Default.BrightnessMedium, "Brightness")
                QuickActionRow(Icons.Default.DoNotDisturbOn, "Focus mode")
                QuickActionRow(Icons.Default.TouchApp, "Touch protect")
                QuickActionRow(Icons.Default.Speed, "FPS test (see note)")
                Spacer(Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = "Close sidebar", tint = Color(0xFFFF6577))
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionRow(icon: ImageVector, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = AccentPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = TextPrimary)
    }
}
