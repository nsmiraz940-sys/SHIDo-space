package com.gamespace.assistant.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.overlay.OverlayService
import com.gamespace.assistant.util.PermissionHelper
import com.gamespace.assistant.ui.theme.*

@Composable
fun ToolsScreen(onRequestScreenRecording: () -> Unit) {
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(16.dp)
    ) {
        Text("Tools", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(Modifier.height(16.dp))

        ToolCard(
            title = "Gaming Sidebar",
            description = "Floating quick-actions bubble that stays on top of your game.",
        ) {
            Button(
                onClick = {
                    if (PermissionHelper.canDrawOverlays(context)) {
                        context.startService(Intent(context, OverlayService::class.java))
                    } else {
                        context.startActivity(PermissionHelper.overlayPermissionIntent(context))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)
            ) { Text("Start sidebar", color = BackgroundDeep) }
        }

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Screen Recording",
            description = "Real MediaProjection recording. Android will show its own one-time consent dialog every session — this app can't skip it.",
        ) {
            Button(
                onClick = onRequestScreenRecording,
                colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)
            ) { Text("Start recording", color = BackgroundDeep) }
        }

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Screenshot",
            description = "Android doesn't let a normal app silently capture another app's screen. Use your device's Power + Volume Down gesture — GameSpace can't replace it, only remind you it exists.",
        ) {}
    }
}

@Composable
private fun ToolCard(title: String, description: String, action: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(description, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(10.dp))
            action()
        }
    }
}
