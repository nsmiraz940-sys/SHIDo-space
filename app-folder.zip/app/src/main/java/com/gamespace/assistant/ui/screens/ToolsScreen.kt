package com.gamespace.assistant.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamespace.assistant.overlay.OverlayService
import com.gamespace.assistant.util.PermissionHelper
import com.gamespace.assistant.ui.theme.*

@Composable
fun ToolsScreen(onRequestScreenRecording: () -> Unit) {
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(16.dp)
    ) {
        Text("Tools", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(Modifier.height(16.dp))

        ToolCard(
            title = "Gaming Sidebar",
            description = "Floating quick-actions bubble that stays on top of your game.",
        ) {
            Button(
                onClick = {
                    if (PermissionHelper.canDrawOverlays(context)) {
                        context.startService(Intent(context, OverlayService::class.java))
                    } else {
                        context.startActivity(PermissionHelper.overlayPermissionIntent(context))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)
            ) { Text("Start sidebar", color = BackgroundDeep) }
        }

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Screen Recording",
            description = "Real MediaProjection recording. Android will show its own one-time consent dialog every session — this app can't skip it.",
        ) {
            Button(
                onClick = onRequestScreenRecording,
                colors = ButtonDefaults.buttonColors(containerColor = AccentPrimary)
            ) { Text("Start recording", color = BackgroundDeep) }
        }

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Screenshot",
            description = "Android doesn't let a normal app silently capture another app's screen. Use your device's Power + Volume Down gesture — GameSpace can't replace it, only remind you it exists.",
        ) {}

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Live FPS test",
            description = "Android gives no normal app access to another app's real render rate — Samsung/Xiaomi's own tools can only do this because they're built into the OS, with privileges a downloaded app never gets. Faking a number here would be exactly the kind of placebo stat this project was built to avoid. What GameSpace can honestly show: this device's max supported refresh rate, and the panel's real thermal status — both already on the Home tab.",
        ) {}

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Open any app floating",
            description = "There's no public Android API letting one app force another arbitrary app into a resizable floating window — that's OEM-private (Samsung/Xiaomi build it into their own system UI). GameSpace can still launch any app normally, and on devices that support it you can enter split-screen yourself via the Recents (square) button — long-press an app there.",
        ) {}

        Spacer(Modifier.height(12.dp))

        ToolCard(
            title = "Close all apps except your games",
            description = "Android does not let a normal app force-close other apps — the closest public API (killBackgroundProcesses) only clears already-cached, idle apps, doesn't touch anything actually running or visible, and reopens them from cache anyway, so it wouldn't free real RAM or help performance. This is also exactly the fake \"RAM boost\" behavior you asked this app to avoid, so GameSpace won't pretend to do it. Gaming Focus (Settings) is the honest equivalent: it silences notifications instead of touching other apps' processes.",
        ) {}
    }
}

@Composable
private fun ToolCard(title: String, description: String, action: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardSurface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(description, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(10.dp))
            action()
        }
    }
}
